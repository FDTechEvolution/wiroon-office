@extends('layouts.coreLayout')

@section('title', 'Dashboard')

@section('content')
    helloooooo
@endsection