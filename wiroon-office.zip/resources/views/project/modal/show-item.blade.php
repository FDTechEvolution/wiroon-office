<!-- Project Item List Modal -->
<div class="modal fade" id="projectShowItemModal" tabindex="-1" role="dialog" aria-labelledby="projectShowItemModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-size-80" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="projectShowItemModalTitle">Project Item 
                    <span id="show-project-name"></span> : 
                    <span id="show-project-customer"></span>
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <div class="table-responsive">
                    <table id="project-items-table" class="table table-align-middle border-bottom">
                        <thead>
                            <tr class="text-muted fs--13">
                                <th class="w--30 hidden-lg-down text-center">
                                    #
                                </th>
                                <th>
                                    <span class="px-2 p-0-xs">NAME</span>
                                </th>
                                <th class="w--180 hidden-lg-down text-center">TYPE</th>
                                <th class="w--180 hidden-lg-down text-center">PROVIDER</th>
                                <th class="w--120 hidden-lg-down text-center">AMOUNT</th>
                            </tr>
                        </thead>

                        <tbody id="item_list">

                        </tbody>
                    </table>
                    <button type="button" class="btn btn-primary btn-v-sm">เพิ่ม Item</button>
                </div>

            </div>
        </div>
    </div>
</div>