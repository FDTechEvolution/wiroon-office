<div class="modal fade" id="projectAddItemModal" tabindex="-1" role="dialog" aria-labelledby="projectAddItemModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-size-80" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <div class="form-group row">
                    <label for="item-name" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                    <div class="col-md-8">
                        <input required placeholder="ชื่อรายการ Project Item" id="item-name" type="text" class="form-control" name="item_name" value="<?php echo e(old('item-name')); ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="item-type" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Type')); ?></label>

                    <div class="col-md-8">
                        <select required id="item-type" name="item_type" class="form-control">
                            <option value="" disabled selected>-- เลือกประเภทของบริการ --</option>
                            <option value="domain">Domain</option>
                            <option value="server">Server</option>
                            <option value="hosting">Hosting</option>
                            <option value="email">Email</option>
                            <option value="design">Design</option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="item-provider" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Provider')); ?></label>

                    <div class="col-md-8">
                        <select required id="item-provider" name="item_provider" class="form-control">
                            <option value="" disabled selected>-- เลือกผู้ให้บริการ --</option>
                            <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($provider->id); ?>"><?php echo e($provider->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="item-amount" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Amount')); ?></label>

                    <div class="col-md-8">
                        <input required placeholder="ราคา Project Item" id="item-amount" type="text" class="form-control" name="item_amount" value="<?php echo e(old('item-amount')); ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="item-description" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                    <div class="col-md-8">
                        <textarea placeholder="รายละเอียดอื่นๆ" id="item-description" class="form-control" name="item_description" rows="3"></textarea>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-12 text-right">
                        <button type="button" class="btn btn-primary btn-sm btn-v-sm">เพิ่ม</button>
                        <button type="button" class="btn btn-secondary btn-sm btn-v-sm" data-dismiss="projectAddItemModal">ยกเลิก</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\git\wiroon-office\resources\views/project/modal/add-item.blade.php ENDPATH**/ ?>