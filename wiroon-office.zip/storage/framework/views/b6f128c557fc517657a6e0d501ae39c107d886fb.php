<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <!-- <script src="<?php echo e(asset('js/app.js')); ?>" defer></script> -->

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">


    <!-- Smarty Style -->
    <link href="<?php echo e(asset('css/smarty_style/core.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/smarty_style/vendor_bundle.min.css')); ?>" rel="stylesheet">
    <!-- up to 10% speed up for external res -->
    <link rel="dns-prefetch" href="https://fonts.googleapis.com/">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com/">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <!-- preloading icon font is helping to speed up a little bit -->
    <link rel="preload" href="<?php echo e(asset('fonts/flaticon/Flaticon.woff2')); ?>" as="font" type="font/woff2" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&amp;display=swap">
    <link rel="apple-touch-icon" href="demo.files/logo/icon_512x512.png">

	<link rel="manifest" href="<?php echo e(asset('images/manifest/manifest.json')); ?>">
	<meta name="theme-color" content="#377dff">

</head>
<body class="layout-admin aside-sticky header-sticky" data-s2t-class="btn-primary btn-sm bg-gradient-default rounded-circle b-0">
    <div id="wrapper" class="d-flex align-items-stretch flex-column">
        <?php echo $__env->make('layouts.components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div id="wrapper_content" class="d-flex flex-fill">
            <?php echo $__env->make('layouts.components.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="middle" class="flex-fill">
                <?php echo $__env->make('flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
        <footer id="footer" class="aside-primary text-white">
            <?php echo $__env->make('layouts.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
    </div>

    <?php echo $__env->yieldContent('modal'); ?>

    <script src="<?php echo e(asset('js/smarty_js/core.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/myapp.js')); ?>"></script>

    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\git\wiroon-office\resources\views/layouts/coreLayout.blade.php ENDPATH**/ ?>