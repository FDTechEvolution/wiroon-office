<!-- Project Edit Modal -->
<div class="modal fade" id="projectEditModal" tabindex="-1" role="dialog" aria-labelledby="projectEditModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-size-80" role="document">
        <div class="modal-content">
            <form method="POST" action="<?php echo e(url('/projects')); ?>">
            <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="projectEditModalTitle">Edit Project</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 col-md-6 border-right">
                            <h5>Project</h5>
                            <div class="form-group row">
                                <label for="edit-name" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                <div class="col-md-8">
                                    <input required placeholder="ชื่อโปรเจค" id="edit-name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="edit-customer" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Customer')); ?></label>
                                <div class="col-md-8">
                                    <select required id="edit-customer" name="customer" class="form-control">
                                        <option value="" disabled selected>-- เลือกลูกค้า --</option>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> : <?php echo e($customer->company_info); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="edit-doc" class="col-md-3 col-form-label text-md-right"><?php echo e(__('DocDate')); ?></label>

                                <div class="col-md-8">
                                    <input required placeholder="วันที่เริ่มใช้บริการ" id="edit-doc" type="date" class="form-control" name="docdate" value="<?php echo e(old('docdate')); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="edit-start" class="col-md-3 col-form-label text-md-right"><?php echo e(__('StartDate')); ?></label>

                                <div class="col-md-8">
                                    <input required placeholder="วันเริ่มรอบบิล" id="edit-start" type="date" class="form-control" name="startdate" value="<?php echo e(old('startdate')); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="edit-end" class="col-md-3 col-form-label text-md-right"><?php echo e(__('EndDate')); ?></label>

                                <div class="col-md-8">
                                    <input required placeholder="วันหมดอายุรอบบิล" id="edit-end" type="date" class="form-control" name="enddate" value="<?php echo e(old('enddate')); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="edit-description" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                                <div class="col-md-8">
                                    <textarea placeholder="รายละเอียดอื่นๆ" id="edit-description" class="form-control" name="description" rows="3"></textarea>
                                </div>
                            </div>

                            <input type="hidden" id="project-item" name="project_item" value="">

                        </div>
                        <div class="col-12 col-md-6">
                            <h5>Project Items <button type="button" class="btn btn-primary btn-sm btn-vv-sm ml-2" onClick="createNewItem()">+ Add Item</button></h5>
                            <div id="create-project-item" class="mt-2 bg-light card" style="display: none;">
                                <div class="card-body">
                                    <div class="form-group row">
                                        <label for="item-name" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                                        <div class="col-md-8">
                                            <input placeholder="ชื่อรายการ Project Item" id="item-name" type="text" class="form-control" name="item_name" value="<?php echo e(old('item-name')); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="item-type" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Type')); ?></label>

                                        <div class="col-md-8">
                                            <select id="item-type" name="item_type" class="form-control">
                                                <option value="" disabled selected>-- เลือกประเภทของบริการ --</option>
                                                <option value="domain">Domain</option>
                                                <option value="server">Server</option>
                                                <option value="hosting">Hosting</option>
                                                <option value="email">Email</option>
                                                <option value="design">Design</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="item-provider" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Provider')); ?></label>

                                        <div class="col-md-8">
                                            <select id="item-provider" name="item_provider" class="form-control">
                                                <option value="" disabled selected>-- เลือกผู้ให้บริการ --</option>
                                                <?php $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($provider->id); ?>"><?php echo e($provider->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="item-amount" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Amount')); ?></label>

                                        <div class="col-md-8">
                                            <input placeholder="ราคา Project Item" id="item-amount" type="number" class="form-control" name="item_amount" value="<?php echo e(old('item-amount')); ?>">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="item-description" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                                        <div class="col-md-8">
                                            <textarea placeholder="รายละเอียดอื่นๆ" id="item-description" class="form-control" name="item_description" rows="3"></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group row mb-0">
                                        <div class="col-12 text-right">
                                            <button type="button" class="btn btn-primary btn-sm btn-v-sm" onClick="addNewItem()">เพิ่มไอเทม</button>
                                            <button type="button" class="btn btn-secondary btn-sm btn-v-sm" onClick="cancelNewItem()">ยกเลิก</button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="project-item-list" style="display: block;">
                                <div class="row">
                                    <div class="col-12">
                                        <ul id="item-list"></ul>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-11 text-right">
                                        Project Amount : <span id="edit-project-amount">0</span> ฿
                                    </div>
                                </div>
                                <span id="test-item"></span>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary btn-sm">เพิ่มโปรเจค</button>
                    <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">ยกเลิก</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\git\wiroon-office\resources\views/project/modal/edit.blade.php ENDPATH**/ ?>