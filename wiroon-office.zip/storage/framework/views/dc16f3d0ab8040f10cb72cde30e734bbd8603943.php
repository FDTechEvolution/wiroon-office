<?php $__env->startSection('title', 'Customer'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gutters-sm">

    <!-- inbox list -->
    <div class="col-12">

        <!-- portlet -->
        <div class="portlet">
            
            <!-- portlet : header -->
            <div class="portlet-header border-bottom">

                <div class="float-end">
                    <button type="button" class="btn btn-sm btn-primary btn-pill px-2 py-1 fs--15 mt--n3" data-toggle="modal" data-target="#customerAddModal">
                        + Add New Customer
                    </button>
                </div>

                <span class="d-block text-muted text-truncate font-weight-medium pt-1">
                    All Customer
                </span>
            </div>
            <!-- /portlet : header -->

            <!-- portlet : body -->
            <div class="portlet-body pt-0">

                <form novalidate class="bs-validate" id="form_id" method="post" action="#!">
                <?php echo csrf_field(); ?>
                    <input type="hidden" id="action" name="action" value=""><!-- value populated by js -->

                    <div class="table-responsive">

                        <table class="table table-align-middle border-bottom mb-6">

                            <thead>
                                <tr class="text-muted fs--13">
                                    <th class="w--30 hidden-lg-down text-center">
                                        #
                                    </th>
                                    <th>
                                        <span class="px-2 p-0-xs">
                                            NAME
                                        </span>
                                    </th>
                                    <th class="w--300 hidden-lg-down">COMPANY</th>
                                    <th class="w--150 hidden-lg-down text-center">MOBILE</th>
                                    <th class="w--150 hidden-lg-down text-center">CREATE</th>
                                    <th class="w--300 hidden-lg-down">DESCRIPTION</th>
                                    <th class="w--60">&nbsp;</th>
                                </tr>
                            </thead>

                            <tbody id="item_list">
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <!-- customer -->
                                    <tr id="customer_id_<?php echo e($key); ?>" class="text-dark">

                                        <td class="hidden-lg-down text-center">
                                            <?php echo e($key + 1); ?>.
                                        </td>

                                        <td style="line-height: 17px;">

                                            <p class="mb-0 text-dark" id="customer_name"><strong><?php echo e($customer->name); ?></strong></p>

                                            <!-- MOBILE ONLY -->
                                            <div class="fs--13 d-block d-xl-none">
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>COMPANY :</strong> <?php echo e($customer->company_info); ?>

                                                </div>
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>MOBILE :</strong> <?php echo e($customer->mobile); ?>

                                                </div>
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>CREATE :</strong> <?php echo e($customer->created_at->format('d/m/Y')); ?>

                                                </div>
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>DESC :</strong> <?php echo e($customer->description); ?>

                                                </div>
                                            </div>
                                            <!-- /MOBILE ONLY -->

                                        </td>

                                        <td class="hidden-lg-down" id="customer_company">
                                            <?php echo e($customer->company_info); ?>

                                        </td>

                                        <td class="hidden-lg-down text-center" id="customer_mobile">
                                            <?php echo e($customer->mobile); ?>

                                        </td>

                                        <td class="hidden-lg-down text-center">
                                            <?php echo e($customer->created_at->format('d/m/Y')); ?>

                                        </td>

                                        <td class="hidden-lg-down" id="customer_description">
                                            <?php echo e($customer->description); ?>

                                        </td>

                                        <td class="text-align-end d-flex">

                                            <a class="text-truncate mr-4" href="#!" title="แก้ไข" data-toggle="modal" data-target="#customerEditModal"
                                                onClick="setDataEditCustomer(<?php echo e($customer->id); ?>)"
                                            >
                                                <i class="fi fi-pencil"></i>
                                            </a>

                                            <a	 href="#!" 
                                                class="text-truncate js-ajax-confirm" 
                                                data-href="/customers/delete/<?php echo e($customer->id); ?>"
                                                data-ajax-confirm-body="ยืนยันการลบลูกค้า <?php echo e($customer->name); ?> ?"

                                                data-ajax-confirm-mode="ajax" 
                                                data-ajax-confirm-method="GET" 

                                                data-ajax-confirm-btn-yes-class="btn-sm btn-danger" 
                                                data-ajax-confirm-btn-yes-text="ลบข้อมูล" 
                                                data-ajax-confirm-btn-yes-icon="fi fi-check" 

                                                data-ajax-confirm-btn-no-class="btn-sm btn-light" 
                                                data-ajax-confirm-btn-no-text="ยกเลิก" 
                                                data-ajax-confirm-btn-no-icon="fi fi-close"

                                                data-ajax-confirm-success-target="#customer_id_<?php echo e($key); ?>" 
                                                data-ajax-confirm-success-target-action="remove">
                                                <i class="fi fi-thrash text-danger"></i>
                                            </a>

                                        </td>

                                    </tr>
                                    <!-- /customer -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                    </div>



                    <!-- options and pagination -->
                    <div class="row text-center-xs">

                        <div class="hidden-lg-down col-12 col-xl-6">

                        </div>

                        <div class="col-12 col-xl-6">
                            <!-- pagination -->
                            <nav aria-label="pagination">
                                <ul class="pagination pagination-pill justify-content-end justify-content-center justify-content-md-end">

                                    <li class="<?php echo e($customers->onFirstPage() ? 'page-item btn-pill disabled' : 'page-item btn-pill'); ?>">
                                        <a class="page-link" href="<?php echo e($customers->previousPageUrl()); ?>" tabindex="-1" aria-disabled="true">ก่อนหน้า</a>
                                    </li>
                                    
                                    <li class="page-item active" aria-current="page">
                                        <?php echo e($customers->links()); ?>

                                    </li>
                                    
                                    <li class="<?php echo e($customers->currentPage() == $customers->lastPage() ? 'page-item disabled' : 'page-item'); ?>">
                                        <a class="page-link" href="<?php echo e($customers->nextPageUrl()); ?>">ถัดไป</a>
                                    </li>

                                </ul>

                                <div class="justify-content-end justify-content-center justify-content-md-end text-right">
                                    <small>หน้า : <?php echo e($customers->currentPage()); ?> / <?php echo e($customers->lastPage()); ?></small>
                                </div>
                            </nav>
                            <!-- pagination -->
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('customer.modal.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('customer.modal.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/customer.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.coreLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\wiroon-office\resources\views/customer/index.blade.php ENDPATH**/ ?>