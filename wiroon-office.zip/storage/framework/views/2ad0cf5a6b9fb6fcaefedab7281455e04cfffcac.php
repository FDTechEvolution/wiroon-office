<?php $__env->startSection('title', 'Project'); ?>

<?php $__env->startSection('content'); ?>
<div class="row gutters-sm">

    <!-- inbox list -->
    <div class="col-12">


        <!-- portlet -->
        <div class="portlet">
            
            <!-- portlet : header -->
            <div class="portlet-header border-bottom">

                <div class="float-end">

                    <button type="button" class="btn btn-sm btn-primary btn-pill px-2 py-1 fs--15 mt--n3" data-toggle="modal" data-target="#projectAddModal">
                        + Add New Project
                    </button>

                </div>

                <span class="d-block text-muted text-truncate font-weight-medium pt-1">
                    All Project
                </span>
            </div>
            <!-- /portlet : header -->


            <!-- portlet : body -->
            <div class="portlet-body pt-0">

                <form novalidate class="bs-validate" id="form_id" method="post" action="#!">
                <?php echo csrf_field(); ?>
                    <input type="hidden" id="action" name="action" value=""><!-- value populated by js -->

                    <div class="table-responsive">

                        <table class="table table-align-middle border-bottom mb-6">

                            <thead>
                                <tr class="text-muted fs--13">
                                    <th class="w--30 hidden-lg-down text-center">
                                        #
                                    </th>
                                    <th>
                                        <span class="px-2 p-0-xs">ชื่อโปรเจค</span>
                                    </th>
                                    <th class="w--220 hidden-lg-down">ลูกค้า</th>
                                    <th class="w--220 hidden-lg-down">วันที่ใช้บริการ</th>
                                    <th class="w--120 hidden-lg-down text-center">ราคา(฿)</th>
                                    <th class="w--100 hidden-lg-down text-center">สถานะ</th>
                                    <th class="w--120">&nbsp;</th>
                                </tr>
                            </thead>

                            <tbody id="item_list">
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <!-- project -->
                                    <tr id="project_id_<?php echo e($key); ?>" class="text-dark">

                                        <td class="hidden-lg-down text-center">
                                            <?php echo e($key + 1); ?>.
                                        </td>

                                        <td style="line-height: 17px;">

                                            <strong><?php echo e($project->name); ?></strong>
                                            <p class="fs--12 mb-0 text-secondary">รายละเอียด : <?php if(isset($project->descriotion)): ?> <?php echo e($project->descriotion); ?> <?php else: ?> - <?php endif; ?></p>

                                            <!-- MOBILE ONLY -->
                                            <div class="fs--13 d-block d-xl-none">
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>DOC :</strong> <?php echo e(date('d-m-Y', strtotime($project->docdate))); ?>

                                                </div>
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>START :</strong> <?php echo e(date('d-m-Y', strtotime($project->startdate))); ?>

                                                </div>
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>END :</strong> <?php echo e(date('d-m-Y', strtotime($project->enddate))); ?>

                                                </div>
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>AMOUNT :</strong> <?php echo e(number_format($project->totalamt)); ?>

                                                </div>
                                                <div class="fs--13 d-block d-xl-none">
                                                    <strong>STATUS :</strong> <?php echo e($project->status); ?>

                                                </div>
                                            </div>
                                            <!-- /MOBILE ONLY -->

                                        </td>

                                        <td class="hidden-lg-down" id="project-doc">
                                            <?php echo e($project->customer->name); ?>

                                            <p class="fs--12 mb-0 text-secondary">Company : <?php echo e($project->customer->company_info); ?></p>
                                        </td>

                                        <td class="hidden-lg-down" id="project-doc">
                                            <p class="fs--12 mb-0">
                                                วันที่เริ่มใช้บริการ : <span class="text-dark"><?php echo e(date('d-m-Y', strtotime($project->docdate))); ?></span>
                                            </p>
                                            <p class="fs--12 mb-0">
                                                วันเริ่มรอบบิล : <span class="text-primary"><?php echo e(date('d-m-Y', strtotime($project->startdate))); ?></span>
                                            </p>
                                            <p class="fs--12 mb-0">
                                                วันหมดอายุรอบบิล : <span class="text-danger"><?php echo e(date('d-m-Y', strtotime($project->enddate))); ?></span>
                                            </p>
                                        </td>

                                        <td class="hidden-lg-down text-center" id="project-amt">
                                            <?php echo e(number_format($project->totalamt)); ?>

                                        </td>

                                        <td class="hidden-lg-down text-center" id="project-status">
                                            <?php if($project->status == 'INACTIVE'): ?>
                                                <small class="badge badge-danger font-weight-normal fs--10"><?php echo e($project->status); ?></small>
                                            <?php elseif($project->status == 'ACTIVE'): ?>
                                                <small class="badge badge-success font-weight-normal fs--10"><?php echo e($project->status); ?></small>
                                            <?php else: ?>
                                                <small class="badge badge-warning font-weight-normal fs--10"><?php echo e($project->status); ?></small>
                                            <?php endif; ?>
                                        </td>

                                        <td class="text-align-en d-flex">

                                            <a class="text-truncate mr-4" href="#!" title="show" data-toggle="modal" data-target="#projectShowItemModal"
                                                onClick="showDataEditProject('<?php echo e($project->items); ?>', '<?php echo e($project->name); ?>', '<?php echo e($project->customer->name); ?>')"
                                            >
                                                <i class="fi fi-pencil"></i>
                                            </a>

                                            <a class="text-truncate mr-4" href="#!" title="แก้ไข" data-toggle="modal" data-target="#projectEditModal"
                                                id="edit-project-btn_<?php echo e($key); ?>" 
                                                data-id="<?php echo e($project->id); ?>" 
                                                data-name="<?php echo e($project->name); ?>" 
                                                data-customer="<?php echo e($project->customer->id); ?>" 
                                                data-docdate="<?php echo e($project->docdate); ?>" 
                                                data-startdate="<?php echo e($project->startdate); ?>" 
                                                data-enddate="<?php echo e($project->enddate); ?>" 
                                                data-totalamt="<?php echo e($project->totalamt); ?>" 
                                                data-items="<?php echo e($project->items); ?>" 
                                                data-description="<?php echo e($project->description); ?>"
                                                onClick="setDataEditProject(<?php echo e($key); ?>)"
                                            >
                                                <i class="fi fi-pencil"></i>
                                            </a>

                                        </td>

                                    </tr>
                                    <!-- /project -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>

                    </div>



                    <!-- options and pagination -->
                    <div class="row text-center-xs">

                        <div class="hidden-lg-down col-12 col-xl-6">

                        </div>

                        <div class="col-12 col-xl-6">
                            <!-- pagination -->
                            <nav aria-label="pagination">
                                <ul class="pagination pagination-pill justify-content-end justify-content-center justify-content-md-end">

                                    <li class="<?php echo e($projects->onFirstPage() ? 'page-item btn-pill disabled' : 'page-item btn-pill'); ?>">
                                        <a class="page-link" href="<?php echo e($projects->previousPageUrl()); ?>" tabindex="-1" aria-disabled="true">ก่อนหน้า</a>
                                    </li>
                                    
                                    <li class="page-item active" aria-current="page">
                                        <?php echo e($projects->links()); ?>

                                    </li>
                                    
                                    <li class="<?php echo e($projects->currentPage() == $projects->lastPage() ? 'page-item disabled' : 'page-item'); ?>">
                                        <a class="page-link" href="<?php echo e($projects->nextPageUrl()); ?>">ถัดไป</a>
                                    </li>

                                </ul>

                                <div class="justify-content-end justify-content-center justify-content-md-end text-right">
                                    <small>หน้า : <?php echo e($projects->currentPage()); ?> / <?php echo e($projects->lastPage()); ?></small>
                                </div>
                            </nav>
                            <!-- pagination -->
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style scoped>
    table.table-align-middle td {
        vertical-align: top;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('project.modal.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('project.modal.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('project.modal.show-item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('js/app/project.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.coreLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\git\wiroon-office\resources\views/project/index.blade.php ENDPATH**/ ?>