<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Project;
use App\Models\ProjectItem;
use App\Models\Customer;
use App\Models\Provider;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class ProjectController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public $project_item = [];

    public function index()
    {
        $projects = Project::with('items', 'customer')->paginate(20);
        $customers = Customer::where('status', 'CO')->get();
        $providers = Provider::where('status', 'CO')->get();

        return view('project.index', ['projects' => $projects, 'customers' => $customers, 'providers' => $providers]);
    }

    public function create(Request $request)
    {
        $project = Project::create([
            'name' => $request->name,
            'customer_id' => $request->customer,
            'docdate' => $request->docdate,
            'startdate' => $request->startdate,
            'enddate' => $request->enddate,
            'totalamt' => 0,
            'status' => 'INACTIVE',
            'description' => $request->description
        ]);

        if(isset($request->project_item)) {
            $amount = $this->createProjectItem($request->project_item, $project->id);

            $project_amt = $this->findById($project->id);
            $project_amt->update([
                'totalamt' => $amount
            ]);
        }
        
        if($project) return redirect()->back()->with('success', 'Add project successed.');

        return redirect()->back()->with('error', 'Add project failed.');
    }

    private function createProjectItem($project_item, $project_id)
    {
        $items = json_decode($project_item, true);
        $totalamt = 0;
        foreach($items as $item) {
            ProjectItem::create([
                'project_id' => $project_id,
                'provider_id' => $item['provider'],
                'name' => $item['name'],
                'type' => $item['type'],
                'amount' => $item['amount'],
                'description' => $item['description']
            ]);

            $totalamt += $item['amount'];
        }

        return $totalamt;
    }



    private function findAll()
    {
        return Project::all();
    }

    private function findById($id)
    {
        return Project::find($id);
    }
}
